#include	"simdef.h"

void insertCutomer(int arrivalTime, int processTime, LinkedDeque *pDeque)
{

}


void processArrival(int currentTime, LinkedDeque *pArrivalDeque, LinkedDeque *pWaitDeque)
{

}


DequeNode* processServiceNodeStart(int currentTime, LinkedDeque *pWaitDeque)
{

}

DequeNode* processServiceNodeEnd(int currentTime, DequeNode *pServiceNode, \
	int *pServiceUserCount, int *pTotalWaitTime)
{

}


void printSimCustomer(int currentTime, SimCustomer customer)
{

}

void printWaitDequeStatus(int currentTime, LinkedDeque *pWaitDeque)
{

}

void printReport(LinkedDeque *pWaitDeque, int serviceUserCount, int totalWaitTime)
{
	
}