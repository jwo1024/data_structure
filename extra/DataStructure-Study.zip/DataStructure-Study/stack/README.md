
# Stack

<img src="https://w.namu.la/s/c73dbaa0dd753939d19a0464feb000054317cdab2c8d80ff0b525b05503286c12d3160df5f8c3352802a01671f85f724f62065d7a97ce0d25082cfaac8553cb7958471dfd4f87308548ded9b375aabfc01ea9d77e77d176338c19fb3c2e3d8c2fdafa98a0514d34357cc3e88c0ec503f" />

#### *출처: 나무위키*

<br />

## 특징

-	Stack 자료구조는 LIFO(후입 선출)이라는 특징을 가지고 있다.
-	FIFO(선입선출)의 특징을 가지는 큐 형태와 반대이다.
-	구현은 큐에 비해서 쉬운 편이나, 응용할 예시가 매우 많다.


# [Stack](https://github.com/MingueKim/DataStructure-Study/tree/main/stack)

