/*
함수 list
{
	Stack	*createStack(); // linked stack 참조 
	t_direction	*setDirection(t_map map); // 
		t_direction	*createDirection();
		void setDirection_LR(t_direction **dir_ptr, t_map map);
		void setDirection_UD(t_direction **dir_ptr, t_map map);
	int	go(direction, map); // 가다가 실패
		while (topNode)
			int	search_left(); // 성공 여부 반환
			int	search_right(); // 성공 여부 반환
			int	search_up(); // 성공 여부 반환
			int	search_down(); // 성공 여부 반환
			free(topNode);
			topNode = popLS();
	void	display_path(); //error 포함
	void	delete_map();
	void	exception_handling(Map) // start node, end node, map이 유효한지
	MapNode	*createMapNode();
}
0 = Path
1 = Wall 
탐색 순서를 결정할 때 map의 가로 세로를 고려해서 탐색 순서를 결정해줘야한다.
flag를 처음에 지정해서 어떤 순서로 탐색할 지를 정해줘야하는데
우햐향 
우상향
좌햐향
좌상향
우향탐색 하향탐색 좌향탐색 상향탐색
우향탐색, 좌향탐색, 하향탐색, 상향탐색
Node->Link = 단일경로
Link로 오면 해당 좌표를 1로 바꿔준다. graph[x][y] == 1 이면 못 가고 0이면 진행
더 이상 갈 곳이 없으면 stack에서 하나 pop하고 다른 경로 있는지 확인하고, 없으면 반복
 */
#include "Maze.h"

/*
int	main(void)
{
	MapNode	*startNode;
	MapNode *endNode;
	Map		*map;
	Direction	*dir;

	int	row;
	int	column;
	char	**graph;

	scanf("%d %d", &row, &column);
	graph = calloc(row, sizeof(char *));
	for (int i = 0; i < row; i++)
	{
		graph[i] = calloc(column + 1, sizeof(char));
		scanf("%s", graph[i]);
	}

	startNode = createMapNode();
	endNode = createMapNode();
	startNode->x = 1;
	startNode->y = 0;
	endNode->x = 4;
	endNode->y = 4;
	map = createMap(5, 5, graph, startNode, endNode);
	dir = setDirection(map);
	printf("result = %d", Go(dir, map));

	return (0);
}
*/

char	**scan_graph(MapNode *startNode, MapNode *endNode, int *row, int *column);

///*
int	main(void)
{
	MapNode	*startNode;
	MapNode *endNode;
	Map		*map;
	Direction	*dir;

	int	row;
	int	column;
	char	**graph;

	startNode = createMapNode();
	endNode = createMapNode();
	graph = scan_graph(startNode, endNode, &row, &column);
	map = createMap(row, column, graph, startNode, endNode);
	dir = setDirection(map);

	printf("result = %d\n", Go(dir, map));
	
	for (int i = 0; i < row; i++)
		printf("%s\n", graph[i]);
}
//*/


char	**scan_graph(MapNode *startNode, MapNode *endNode, int *row, int *column)
{
	char **graph;

	scanf("%d %d", row, column);
	graph = calloc(*row, sizeof(char *));
	for (int i = 0; i < *row; i++)
	{
		graph[i] = calloc(*column + 1, sizeof(char));
		for (int j = 0; j < *column; j++)
		{
			scanf(" %c", &graph[i][j]);
			if (graph[i][j] == 's')
			{
				startNode->x = j;
				startNode->y = i;
			}
			else if (graph[i][j] == 'e')
			{
				endNode->x = j;
				endNode->y = i;
				graph[i][j] = '0';
			}
		}
		graph[i][*column] = '\0';
	}
	return (graph);
}





/*
// 
5 5
1s011
11001
11101
11101
111e1

10011
11001
11101
11101
11101

5 5
100e1
10111
00000
11011
s0011

5 5
10011
11001
11101
11101
11100

*/


// display map;